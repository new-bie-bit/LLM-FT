import streamlit as st
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
from peft import PeftModel

# 模型和 tokenizer 加载函数，支持是否加载 LoRA
@st.cache_resource
def load_model_and_tokenizer(use_lora=True):
    base_model_path = "/data0/wengcchuang/LLM/LLaMA-Factory/saves/Qwen3-4B"
    lora_model_path = "/data0/wengcchuang/LLM/LLaMA-Factory/saves/Qwen3-4B-Instruct/lora/train_2025-05-24-20-55-14"

    tokenizer = AutoTokenizer.from_pretrained(base_model_path, local_files_only=True, trust_remote_code=True)
    base_model = AutoModelForCausalLM.from_pretrained(base_model_path, torch_dtype=torch.float16, local_files_only=True, trust_remote_code=True)
    base_model = base_model.to("cuda" if torch.cuda.is_available() else "cpu")

    if use_lora:
        model = PeftModel.from_pretrained(base_model, lora_model_path, local_files_only=True)
        model = model.merge_and_unload()
    else:
        model = base_model

    model.eval()
    return model, tokenizer

# 对话 prompt 构造
def build_prompt(style, history, user_input):
    style_map = {
        "温柔": "请用温柔而简洁的语气回复，并且进行适当追问。",
        "鼓励": "请用积极鼓励的语气给予支持，简洁温暖，并适当追问。",
        "安静": "请用安静、柔和、不喧哗的语气回复，让对方安心。",
        "可爱": "请用可爱亲切的语气安慰对方，语气自然轻松，适当撒娇和卖萌。",
    }
    style_prompt = style_map.get(style, "请用温柔而简洁的语气回复，并进行适当追问。")

    prompt = f"<|im_start|>system\n{style_prompt}<|im_end|>"
    for user, bot in history:
        prompt += f"<|im_start|>user\n{user}<|im_end|><|im_start|>assistant\n{bot}<|im_end|>"
    prompt += f"<|im_start|>user\n{user_input}<|im_end|><|im_start|>assistant\n"
    return prompt

# 响应生成函数
import re

def generate_response(model, tokenizer, prompt, max_tokens=512, temperature=0.7, top_p=0.9):
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    
    # 不需要也不能转换成 float16，会报错
    outputs = model.generate(
        **inputs,
        max_new_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        do_sample=True,
        eos_token_id=tokenizer.eos_token_id,
        pad_token_id=tokenizer.pad_token_id,
        no_repeat_ngram_size=3,
        early_stopping=True,
    )

    response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    # 清理一下 response，去掉冗余换行和空白
    response = re.sub(r"\n+", "\n", response).strip()
    response = clean_response(response)
    return response

def clean_response(response: str) -> str:
    # 去除 <think> 标签及其前面的空白
    if "<think>" in response:
        response = response.split("<think>", 1)[1].strip()
    return response
# 主函数
def main():
    st.set_page_config(page_title="微调演示", page_icon="🦙")
    st.title("🦙 Fine-tuned 模型演示")

    use_lora = st.checkbox("使用 LoRA 微调权重", value=True)

    # 加载模型和 tokenizer
    with st.spinner("正在加载模型…"):
        model, tokenizer = load_model_and_tokenizer(use_lora)

    # 聊天记录初始化
    if "history" not in st.session_state:
        st.session_state.history = []
    if "style" not in st.session_state:
        st.session_state.style = "温柔"

    selected_style = st.selectbox("🌸 回复风格：", ["温柔", "鼓励", "安静", "可爱"],
                                  index=["温柔", "鼓励", "安静", "可爱"].index(st.session_state.style))
    st.session_state.style = selected_style

    user_input = st.text_input("💬 请输入你的问题：", key="input")

    if st.button("🚀 发送"):
        if user_input.strip() != "":
            with st.spinner("模型思考中…"):
                prompt = build_prompt(st.session_state.style, st.session_state.history, user_input)
                reply = generate_response(model, tokenizer, prompt)
            st.session_state.history.append((user_input, reply))
            st.rerun()

    # 聊天记录展示
    for user, bot in st.session_state.history:
        st.markdown(f"**🧑用户：** {user}")
        st.markdown(f"**🤖模型：** {bot}")

if __name__ == "__main__":
    main()
