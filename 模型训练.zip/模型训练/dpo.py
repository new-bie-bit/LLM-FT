# train_dpo.py
import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, PreTrainedTokenizer
from trl import DPOTrainer, DPOConfig
from datasets import load_dataset, Features, Value
from peft import PeftModel, PeftConfig

model_name_or_path = "/data/yxmeng/qwen" # 模型路径
adapter_name_or_path = "/data/yxmeng/Qwen/finetune_demo/output/checkpoint-80000" # 适配器路径
output_dir = "./dpo_qwen"

train_file = "/data/yxmeng/Qwen/finetune_demo/RHLF/hh-rlhf/merged_train.jsonl"  # 训练数据文件
val_file = "/data/yxmeng/Qwen/finetune_demo/RHLF/hh-rlhf/merged_test.jsonl"  # 验证数据文件

tokenizer = AutoTokenizer.from_pretrained(model_name_or_path, trust_remote_code=True)
base_model = AutoModelForCausalLM.from_pretrained(model_name_or_path, trust_remote_code=True, torch_dtype=torch.bfloat16).cuda()

model = PeftModel.from_pretrained(base_model, adapter_name_or_path)

def get_dataset(path):
    features = Features({
        "prompt": Value("string"),
        "chosen": Value("string"),
        "rejected": Value("string")
    })

    raw_dataset = load_dataset('json', data_files=path, features=features)
    
    def preprocess(example):
        return {
            "prompt": example["prompt"],
            "chosen": example["chosen"],
            "rejected": example["rejected"]
        }
    
    return raw_dataset.map(preprocess)

train_dataset = get_dataset(train_file)
val_dataset = get_dataset(val_file)

dpo_config = DPOConfig(
    beta=0.1,
    learning_rate=5e-5,
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    gradient_accumulation_steps=8,
    num_train_epochs=1,
    log_level='info',
    # evaluation_strategy="steps",
    eval_steps=500,
    save_steps=1000,
    save_total_limit=2,
    output_dir=output_dir,
    remove_unused_columns=False,
    optim="adamw_torch"
)

# class MyDPOProcessor:
#     def __init__(self, tokenizer: PreTrainedTokenizer):
#         self.tokenizer = tokenizer

#     def __call__(self, example):
#         # 提取 prompt, chosen, rejected 字段
#         prompt = example['prompt']
#         chosen = example['chosen']
#         rejected = example['rejected']
    
#         prompt_input_ids = self.tokenizer(prompt, truncation=True, padding=True, add_special_tokens=True)["input_ids"]
#         chosen_input_ids = self.tokenizer(chosen, truncation=True, padding=True, add_special_tokens=True)["input_ids"]
#         rejected_input_ids = self.tokenizer(rejected, truncation=True, padding=True, add_special_tokens=True)["input_ids"]

#         return {
#             'input_ids': prompt_input_ids,
#             'chosen_ids': chosen_input_ids,
#             'rejected_ids': rejected_input_ids
#         }
    
# processing_class = MyDPOProcessor(tokenizer)

# ====== 启动训练 ======
trainer = DPOTrainer(
    model=model,
    args=dpo_config,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    tokenizer=tokenizer,
    #processing_class=processing_class,
)

trainer.train()